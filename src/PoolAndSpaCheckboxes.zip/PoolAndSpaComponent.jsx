// const PoolAndSpaComponent = () => {

//     return (
//         <div id="pool-and-spa-component">
//             <h2>Pool And Spa</h2>
//             {/* Outdoor Pool (All Year) (Star), Indoor Pool (Star, Checked), Sauna (Star, Checked),
//             Rooftop Pool (Checked), Outdoor Pool (Seasonal) (Star), Hot Tub/Jacuzzi (Star),
//             Fitness Room (Star), Infinity Pool (Star)
//             SHOW LESS */}
//         </div>
//     );
// }

// export default PoolAndSpaComponent;