// const FoodAndDrinkComponent = () => {

//     return (
//         <div id="food-and-drink-component">
//             <h2>Food And Drink</h2>
//             {/* Grocery Deliveries (Checked), BBQ Facilities, Room Service */}
//         </div>
//     );
// }

// export default FoodAndDrinkComponent;